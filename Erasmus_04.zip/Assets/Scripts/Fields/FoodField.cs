﻿using UnityEngine;
using System.Collections;

public class FoodField : Field {

	// Use this for initialization
	protected override void Awake () {
		base.Awake ();
	}
	
	// Update is called once per frame
	protected override void Update () {
		base.Update ();
	}
}
